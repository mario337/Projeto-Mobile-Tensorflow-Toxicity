# Projeto-Mobile-Tensorflow-Toxicity --Grupo 5
# Nomes:
- Mario Andrade Neto
- Henrique Correia Zacari
- Enzo Corbanezzi
- Eduardo Pereira 
- Guilherme Godinho
- Haroldo Kimura
